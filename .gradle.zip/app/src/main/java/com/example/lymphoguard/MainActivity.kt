package com.example.lymphoguard

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.InputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothSocket: BluetoothSocket? = null
    private var inputStream: InputStream? = null

    private val sppUUID: UUID =
        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private var onDataReceived: ((String) -> Unit)? = null

    private val bluetoothPermissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->

            if (granted) {
                connectToLymphoGuard()
            } else {
                onDataReceived?.invoke("Bluetooth permission denied")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bluetoothAdapter =
            BluetoothAdapter.getDefaultAdapter()

        setContent {

            var status by remember {
                mutableStateOf("Bluetooth: Disconnected")
            }

            var fsrValue by remember {
                mutableStateOf("---")
            }

            var circumference by remember {
                mutableStateOf("---")
            }

            onDataReceived = { data ->

                runOnUiThread {

                    if (data == "CONNECTED") {

                        status = "Bluetooth: Connected 🟢"

                    } else if (data.startsWith("FSR:")) {

                        try {

                            val parts =
                                data.split(",")

                            if (parts.size >= 2) {

                                val fsr =
                                    parts[0]
                                        .substringAfter("FSR:")
                                        .trim()

                                val circ =
                                    parts[1]
                                        .substringAfter("Circumference:")
                                        .trim()

                                fsrValue = fsr
                                circumference = "$circ cm"
                            }

                        } catch (e: Exception) {

                            // Ignore malformed data
                        }
                    }
                }
            }

            LymphoGuardScreen(
                status = status,
                fsrValue = fsrValue,
                circumference = circumference,
                onConnect = {

                    checkBluetoothPermission()
                }
            )
        }
    }

    private fun checkBluetoothPermission() {

        if (android.os.Build.VERSION.SDK_INT >=
            android.os.Build.VERSION_CODES.S
        ) {

            if (
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_CONNECT
                ) != PackageManager.PERMISSION_GRANTED
            ) {

                bluetoothPermissionLauncher.launch(
                    Manifest.permission.BLUETOOTH_CONNECT
                )

            } else {

                connectToLymphoGuard()
            }

        } else {

            connectToLymphoGuard()
        }
    }

    @SuppressLint("MissingPermission")
    private fun connectToLymphoGuard() {

        val adapter = bluetoothAdapter

        if (adapter == null) {

            onDataReceived?.invoke(
                "Bluetooth not supported"
            )

            return
        }

        if (!adapter.isEnabled) {

            onDataReceived?.invoke(
                "Please turn Bluetooth ON"
            )

            return
        }

        thread {

            try {

                val pairedDevices =
                    adapter.bondedDevices

                var lymphoGuardDevice:
                        BluetoothDevice? = null

                for (device in pairedDevices) {

                    if (device.name == "LymphoGuard") {

                        lymphoGuardDevice = device
                        break
                    }
                }

                if (lymphoGuardDevice == null) {

                    onDataReceived?.invoke(
                        "LymphoGuard not paired"
                    )

                    return@thread
                }

                bluetoothSocket =
                    lymphoGuardDevice.createRfcommSocketToServiceRecord(
                        sppUUID
                    )

                bluetoothAdapter?.cancelDiscovery()

                bluetoothSocket?.connect()

                inputStream =
                    bluetoothSocket?.inputStream

                onDataReceived?.invoke("CONNECTED")

                readBluetoothData()

            } catch (e: Exception) {

                onDataReceived?.invoke(
                    "Connection failed"
                )
            }
        }
    }

    private fun readBluetoothData() {

        thread {

            try {

                val buffer =
                    ByteArray(1024)

                var bytes: Int

                while (
                    bluetoothSocket?.isConnected == true
                ) {

                    bytes =
                        inputStream?.read(buffer) ?: -1

                    if (bytes > 0) {

                        val received =
                            String(
                                buffer,
                                0,
                                bytes
                            )

                        val lines =
                            received.split("\n")

                        for (line in lines) {

                            val cleanLine =
                                line.trim()

                            if (
                                cleanLine.startsWith("FSR:")
                            ) {

                                onDataReceived?.invoke(
                                    cleanLine
                                )
                            }
                        }
                    }
                }

            } catch (e: Exception) {

                onDataReceived?.invoke(
                    "Disconnected"
                )
            }
        }
    }

    override fun onDestroy() {

        super.onDestroy()

        try {

            inputStream?.close()
            bluetoothSocket?.close()

        } catch (e: Exception) {
        }
    }
}

@Composable
fun LymphoGuardScreen(
    status: String,
    fsrValue: String,
    circumference: String,
    onConnect: () -> Unit
) {

    Column(

        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),

        horizontalAlignment =
            Alignment.CenterHorizontally,

        verticalArrangement =
            Arrangement.Top
    ) {

        Spacer(
            modifier = Modifier.height(40.dp)
        )

        Text(
            text = "LYMPHOGUARD",
            fontSize = 30.sp,
            style = MaterialTheme.typography.headlineLarge
        )

        Spacer(
            modifier = Modifier.height(20.dp)
        )

        Text(
            text = status,
            fontSize = 18.sp
        )

        Spacer(
            modifier = Modifier.height(25.dp)
        )

        Button(
            onClick = onConnect,
            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                text = "CONNECT TO LYMPHOGUARD"
            )
        }

        Spacer(
            modifier = Modifier.height(50.dp)
        )

        Text(
            text = "FSR VALUE",
            fontSize = 18.sp
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        Text(
            text = fsrValue,
            fontSize = 45.sp
        )

        Spacer(
            modifier = Modifier.height(35.dp)
        )

        Text(
            text = "CIRCUMFERENCE",
            fontSize = 18.sp
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        Text(
            text = circumference,
            fontSize = 35.sp
        )

        Spacer(
            modifier = Modifier.height(30.dp)
        )

        Text(
            text = "Live monitoring",
            fontSize = 16.sp
        )
    }
}